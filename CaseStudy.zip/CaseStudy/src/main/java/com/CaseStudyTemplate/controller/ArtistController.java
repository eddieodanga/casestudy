package com.CaseStudyTemplate.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ArtistController {

	
	
}
